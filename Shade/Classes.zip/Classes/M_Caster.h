#ifndef __M_CASTER_H__
#define __M_CASTER_H__
#include "M_Shadow.h"

class Caster : public Shadow {
	enum ActionType {};  // TODO fill this
};

#endif /*__M_CASTER_H__*/
