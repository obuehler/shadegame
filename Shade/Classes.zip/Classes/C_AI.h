#ifndef __C_AI_H__
#define __C_AI_H__

#include <M_MovingObject.h>

class AIController {

	


};

#endif